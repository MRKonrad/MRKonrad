extern int v3p_netlib_ztrsv_(
  char *uplo,
  char *trans,
  char *diag,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublecomplex *x,
  v3p_netlib_integer *incx,
  v3p_netlib_ftnlen uplo_len,
  v3p_netlib_ftnlen trans_len,
  v3p_netlib_ftnlen diag_len
  );
