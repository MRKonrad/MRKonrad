extern int v3p_netlib_dsesrt_(
  char *which,
  v3p_netlib_logical *apply,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *x,
  v3p_netlib_integer *na,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_ftnlen which_len
  );
