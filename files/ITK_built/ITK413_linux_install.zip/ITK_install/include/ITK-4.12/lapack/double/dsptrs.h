extern int v3p_netlib_dsptrs_(
  char *uplo,
  v3p_netlib_integer *n,
  v3p_netlib_integer *nrhs,
        v3p_netlib_doublereal *ap,
  v3p_netlib_integer *ipiv,
  v3p_netlib_doublereal *b,
  v3p_netlib_integer *ldb,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen uplo_len
);

