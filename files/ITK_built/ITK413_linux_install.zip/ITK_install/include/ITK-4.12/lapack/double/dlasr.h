extern int v3p_netlib_dlasr_(
  char *side,
  char *pivot,
  char *direct,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *c__,
  v3p_netlib_doublereal *s,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_ftnlen side_len,
  v3p_netlib_ftnlen pivot_len,
  v3p_netlib_ftnlen direct_len
  );
