extern int v3p_netlib_dtgexc_(
  v3p_netlib_logical *wantq,
  v3p_netlib_logical *wantz,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublereal *b,
  v3p_netlib_integer *ldb,
  v3p_netlib_doublereal *q,
  v3p_netlib_integer *ldq,
  v3p_netlib_doublereal *z__,
  v3p_netlib_integer *ldz,
  v3p_netlib_integer *ifst,
  v3p_netlib_integer *ilst,
  v3p_netlib_doublereal *work,
  v3p_netlib_integer *lwork,
  v3p_netlib_integer *info
  );
