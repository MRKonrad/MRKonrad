extern v3p_netlib_doublereal v3p_netlib_dlapy3_(
  v3p_netlib_doublereal *x,
  v3p_netlib_doublereal *y,
  v3p_netlib_doublereal *z__
  );
