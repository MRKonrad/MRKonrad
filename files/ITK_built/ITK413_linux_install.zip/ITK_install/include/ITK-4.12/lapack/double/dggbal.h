extern int v3p_netlib_dggbal_(
  char *job,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublereal *b,
  v3p_netlib_integer *ldb,
  v3p_netlib_integer *ilo,
  v3p_netlib_integer *ihi,
  v3p_netlib_doublereal *lscale,
  v3p_netlib_doublereal *rscale,
  v3p_netlib_doublereal *work,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen job_len
  );
