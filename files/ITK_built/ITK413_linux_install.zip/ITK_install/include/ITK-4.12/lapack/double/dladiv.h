extern int v3p_netlib_dladiv_(
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *b,
  v3p_netlib_doublereal *c__,
  v3p_netlib_doublereal *d__,
  v3p_netlib_doublereal *p,
  v3p_netlib_doublereal *q
  );
