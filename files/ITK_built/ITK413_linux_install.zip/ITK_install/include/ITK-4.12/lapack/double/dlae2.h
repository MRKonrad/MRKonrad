extern int v3p_netlib_dlae2_(
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *b,
  v3p_netlib_doublereal *c__,
  v3p_netlib_doublereal *rt1,
  v3p_netlib_doublereal *rt2
  );
