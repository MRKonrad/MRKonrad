extern void v3p_netlib_dlartg_init();
extern int v3p_netlib_dlartg_(
  v3p_netlib_doublereal *f,
  v3p_netlib_doublereal *g,
  v3p_netlib_doublereal *cs,
  v3p_netlib_doublereal *sn,
  v3p_netlib_doublereal *r__
  );
