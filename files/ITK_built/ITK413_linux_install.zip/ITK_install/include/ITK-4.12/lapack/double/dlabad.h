extern int v3p_netlib_dlabad_(
  v3p_netlib_doublereal *small,
  v3p_netlib_doublereal *large
  );
