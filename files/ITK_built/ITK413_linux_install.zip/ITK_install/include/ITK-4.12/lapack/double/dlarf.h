extern int v3p_netlib_dlarf_(
  char *side,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *v,
  v3p_netlib_integer *incv,
  v3p_netlib_doublereal *tau,
  v3p_netlib_doublereal *c__,
  v3p_netlib_integer *ldc,
  v3p_netlib_doublereal *work,
  v3p_netlib_ftnlen side_len
  );
