extern int v3p_netlib_dlacon_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *v,
  v3p_netlib_doublereal *x,
  v3p_netlib_integer *isgn,
  v3p_netlib_doublereal *est,
  v3p_netlib_integer *kase
  );
