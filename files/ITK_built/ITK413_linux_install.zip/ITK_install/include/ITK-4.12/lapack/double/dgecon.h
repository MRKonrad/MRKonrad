extern int v3p_netlib_dgecon_(
  char *norm,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublereal *anorm,
  v3p_netlib_doublereal *rcond,
  v3p_netlib_doublereal *work,
  v3p_netlib_integer *iwork,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen norm_len
  );
