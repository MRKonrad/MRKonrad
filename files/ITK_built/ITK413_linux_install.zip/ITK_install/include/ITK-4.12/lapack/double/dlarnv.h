extern int v3p_netlib_dlarnv_(
  v3p_netlib_integer *idist,
  v3p_netlib_integer *iseed,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *x
  );
