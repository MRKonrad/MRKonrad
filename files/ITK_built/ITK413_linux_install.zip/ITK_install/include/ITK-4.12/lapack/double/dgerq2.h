extern int v3p_netlib_dgerq2_(
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublereal *tau,
  v3p_netlib_doublereal *work,
  v3p_netlib_integer *info
  );
