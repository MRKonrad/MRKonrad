extern int v3p_netlib_dlatdf_(
  v3p_netlib_integer *ijob,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *z__,
  v3p_netlib_integer *ldz,
  v3p_netlib_doublereal *rhs,
  v3p_netlib_doublereal *rdsum,
  v3p_netlib_doublereal *rdscal,
  v3p_netlib_integer *ipiv,
  v3p_netlib_integer *jpiv
  );
