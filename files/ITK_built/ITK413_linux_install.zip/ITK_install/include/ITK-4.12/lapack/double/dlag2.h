extern int v3p_netlib_dlag2_(
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublereal *b,
  v3p_netlib_integer *ldb,
  v3p_netlib_doublereal *safmin,
  v3p_netlib_doublereal *scale1,
  v3p_netlib_doublereal *scale2,
  v3p_netlib_doublereal *wr1,
  v3p_netlib_doublereal *wr2,
  v3p_netlib_doublereal *wi
  );
