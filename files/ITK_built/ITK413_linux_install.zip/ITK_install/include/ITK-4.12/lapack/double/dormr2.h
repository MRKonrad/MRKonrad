extern int v3p_netlib_dormr2_(
  char *side,
  char *trans,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_integer *k,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublereal *tau,
  v3p_netlib_doublereal *c__,
  v3p_netlib_integer *ldc,
  v3p_netlib_doublereal *work,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen side_len,
  v3p_netlib_ftnlen trans_len
  );
