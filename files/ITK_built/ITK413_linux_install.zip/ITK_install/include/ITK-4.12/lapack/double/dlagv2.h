extern int v3p_netlib_dlagv2_(
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublereal *b,
  v3p_netlib_integer *ldb,
  v3p_netlib_doublereal *alphar,
  v3p_netlib_doublereal *alphai,
  v3p_netlib_doublereal *beta,
  v3p_netlib_doublereal *csl,
  v3p_netlib_doublereal *snl,
  v3p_netlib_doublereal *csr,
  v3p_netlib_doublereal *snr
  );
