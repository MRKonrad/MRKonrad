extern int v3p_netlib_dlasv2_(
  v3p_netlib_doublereal *f,
  v3p_netlib_doublereal *g,
  v3p_netlib_doublereal *h__,
  v3p_netlib_doublereal *ssmin,
  v3p_netlib_doublereal *ssmax,
  v3p_netlib_doublereal *snr,
  v3p_netlib_doublereal *csr,
  v3p_netlib_doublereal *snl,
  v3p_netlib_doublereal *csl
  );
