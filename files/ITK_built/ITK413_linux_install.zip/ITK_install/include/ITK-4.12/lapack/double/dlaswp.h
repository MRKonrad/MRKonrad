extern int v3p_netlib_dlaswp_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_integer *k1,
  v3p_netlib_integer *k2,
  v3p_netlib_integer *ipiv,
  v3p_netlib_integer *incx
  );
