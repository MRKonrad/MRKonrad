extern int v3p_netlib_dlarft_(
  char *direct,
  char *storev,
  v3p_netlib_integer *n,
  v3p_netlib_integer *k,
  v3p_netlib_doublereal *v,
  v3p_netlib_integer *ldv,
  v3p_netlib_doublereal *tau,
  v3p_netlib_doublereal *t,
  v3p_netlib_integer *ldt,
  v3p_netlib_ftnlen direct_len,
  v3p_netlib_ftnlen storev_len
  );
