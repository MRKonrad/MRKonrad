extern v3p_netlib_doublereal v3p_netlib_dlapy2_(
  v3p_netlib_doublereal *x,
  v3p_netlib_doublereal *y
  );
