extern int v3p_netlib_dlaruv_(
  v3p_netlib_integer *iseed,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *x
  );
