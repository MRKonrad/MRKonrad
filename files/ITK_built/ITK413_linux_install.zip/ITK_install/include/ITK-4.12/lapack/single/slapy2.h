extern v3p_netlib_E_f v3p_netlib_slapy2_(
  v3p_netlib_real *x,
  v3p_netlib_real *y
  );
