extern int v3p_netlib_slassq_(
  v3p_netlib_integer *n,
  v3p_netlib_real *x,
  v3p_netlib_integer *incx,
  v3p_netlib_real *scale,
  v3p_netlib_real *sumsq
  );
