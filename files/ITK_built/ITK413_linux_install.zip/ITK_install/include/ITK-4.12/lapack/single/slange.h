extern v3p_netlib_E_f v3p_netlib_slange_(
  char *norm,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_real *a,
  v3p_netlib_integer *lda,
  v3p_netlib_real *work,
  v3p_netlib_ftnlen norm_len
  );
