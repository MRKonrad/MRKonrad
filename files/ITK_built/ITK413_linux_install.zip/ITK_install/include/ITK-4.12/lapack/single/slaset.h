extern int v3p_netlib_slaset_(
  char *uplo,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_real *alpha,
  v3p_netlib_real *beta,
  v3p_netlib_real *a,
  v3p_netlib_integer *lda,
  v3p_netlib_ftnlen uplo_len
  );
