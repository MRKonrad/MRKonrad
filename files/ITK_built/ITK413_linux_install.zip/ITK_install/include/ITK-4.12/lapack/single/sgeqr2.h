extern int v3p_netlib_sgeqr2_(
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_real *a,
  v3p_netlib_integer *lda,
  v3p_netlib_real *tau,
  v3p_netlib_real *work,
  v3p_netlib_integer *info
  );
