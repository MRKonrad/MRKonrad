extern int v3p_netlib_slarf_(
  char *side,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_real *v,
  v3p_netlib_integer *incv,
  v3p_netlib_real *tau,
  v3p_netlib_real *c__,
  v3p_netlib_integer *ldc,
  v3p_netlib_real *work,
  v3p_netlib_ftnlen side_len
  );
