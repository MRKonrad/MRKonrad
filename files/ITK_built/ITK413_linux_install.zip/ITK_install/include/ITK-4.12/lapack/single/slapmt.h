extern int v3p_netlib_slapmt_(
  v3p_netlib_logical *forwrd,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_real *x,
  v3p_netlib_integer *ldx,
  v3p_netlib_integer *k
  );
