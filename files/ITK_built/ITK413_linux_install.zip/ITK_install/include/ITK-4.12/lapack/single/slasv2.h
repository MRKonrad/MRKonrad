extern int v3p_netlib_slasv2_(
  v3p_netlib_real *f,
  v3p_netlib_real *g,
  v3p_netlib_real *h__,
  v3p_netlib_real *ssmin,
  v3p_netlib_real *ssmax,
  v3p_netlib_real *snr,
  v3p_netlib_real *csr,
  v3p_netlib_real *snl,
  v3p_netlib_real *csl
  );
