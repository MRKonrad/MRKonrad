extern int v3p_netlib_slags2_(
  v3p_netlib_logical *upper,
  v3p_netlib_real *a1,
  v3p_netlib_real *a2,
  v3p_netlib_real *a3,
  v3p_netlib_real *b1,
  v3p_netlib_real *b2,
  v3p_netlib_real *b3,
  v3p_netlib_real *csu,
  v3p_netlib_real *snu,
  v3p_netlib_real *csv,
  v3p_netlib_real *snv,
  v3p_netlib_real *csq,
  v3p_netlib_real *snq
  );
