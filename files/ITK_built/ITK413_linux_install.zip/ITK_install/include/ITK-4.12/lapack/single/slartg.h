extern void v3p_netlib_slartg_init();
extern int v3p_netlib_slartg_(
  v3p_netlib_real *f,
  v3p_netlib_real *g,
  v3p_netlib_real *cs,
  v3p_netlib_real *sn,
  v3p_netlib_real *r__
  );
