extern int v3p_netlib_slas2_(
  v3p_netlib_real *f,
  v3p_netlib_real *g,
  v3p_netlib_real *h__,
  v3p_netlib_real *ssmin,
  v3p_netlib_real *ssmax
  );
