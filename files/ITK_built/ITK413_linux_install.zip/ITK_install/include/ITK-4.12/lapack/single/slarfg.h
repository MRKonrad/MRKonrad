extern int v3p_netlib_slarfg_(
  v3p_netlib_integer *n,
  v3p_netlib_real *alpha,
  v3p_netlib_real *x,
  v3p_netlib_integer *incx,
  v3p_netlib_real *tau
  );
