extern int v3p_netlib_zdrscl_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *sa,
  v3p_netlib_doublecomplex *sx,
  v3p_netlib_integer *incx
  );
