extern int v3p_netlib_zlahqr_(
  v3p_netlib_logical *wantt,
  v3p_netlib_logical *wantz,
  v3p_netlib_integer *n,
  v3p_netlib_integer *ilo,
  v3p_netlib_integer *ihi,
  v3p_netlib_doublecomplex *h__,
  v3p_netlib_integer *ldh,
  v3p_netlib_doublecomplex *w,
  v3p_netlib_integer *iloz,
  v3p_netlib_integer *ihiz,
  v3p_netlib_doublecomplex *z__,
  v3p_netlib_integer *ldz,
  v3p_netlib_integer *info
  );
