extern int v3p_netlib_zgebal_(
  char *job,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_integer *ilo,
  v3p_netlib_integer *ihi,
  v3p_netlib_doublereal *scale,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen job_len
  );
