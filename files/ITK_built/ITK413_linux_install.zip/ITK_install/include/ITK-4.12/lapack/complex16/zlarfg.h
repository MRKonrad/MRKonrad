extern int v3p_netlib_zlarfg_(
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *alpha,
  v3p_netlib_doublecomplex *x,
  v3p_netlib_integer *incx,
  v3p_netlib_doublecomplex *tau
  );
