extern int v3p_netlib_zlascl_(
  char *type__,
  v3p_netlib_integer *kl,
  v3p_netlib_integer *ku,
  v3p_netlib_doublereal *cfrom,
  v3p_netlib_doublereal *cto,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen type_len
  );
