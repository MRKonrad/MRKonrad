extern int v3p_netlib_ztgexc_(
  v3p_netlib_logical *wantq,
  v3p_netlib_logical *wantz,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublecomplex *b,
  v3p_netlib_integer *ldb,
  v3p_netlib_doublecomplex *q,
  v3p_netlib_integer *ldq,
  v3p_netlib_doublecomplex *z__,
  v3p_netlib_integer *ldz,
  v3p_netlib_integer *ifst,
  v3p_netlib_integer *ilst,
  v3p_netlib_integer *info
  );
