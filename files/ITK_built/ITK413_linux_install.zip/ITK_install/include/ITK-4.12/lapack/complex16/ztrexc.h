extern int v3p_netlib_ztrexc_(
  char *compq,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *t,
  v3p_netlib_integer *ldt,
  v3p_netlib_doublecomplex *q,
  v3p_netlib_integer *ldq,
  v3p_netlib_integer *ifst,
  v3p_netlib_integer *ilst,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen compq_len
  );
