extern int v3p_netlib_zlacn2_(
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *v,
  v3p_netlib_doublecomplex *x,
  v3p_netlib_doublereal *est,
  v3p_netlib_integer *kase,
  v3p_netlib_integer *isave
  );
