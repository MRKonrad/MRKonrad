extern int v3p_netlib_zlahrd_(
  v3p_netlib_integer *n,
  v3p_netlib_integer *k,
  v3p_netlib_integer *nb,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublecomplex *tau,
  v3p_netlib_doublecomplex *t,
  v3p_netlib_integer *ldt,
  v3p_netlib_doublecomplex *y,
  v3p_netlib_integer *ldy
  );
