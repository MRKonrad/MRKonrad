extern int v3p_netlib_zgebak_(
  char *job,
  char *side,
  v3p_netlib_integer *n,
  v3p_netlib_integer *ilo,
  v3p_netlib_integer *ihi,
  v3p_netlib_doublereal *scale,
  v3p_netlib_integer *m,
  v3p_netlib_doublecomplex *v,
  v3p_netlib_integer *ldv,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen job_len,
  v3p_netlib_ftnlen side_len
  );
