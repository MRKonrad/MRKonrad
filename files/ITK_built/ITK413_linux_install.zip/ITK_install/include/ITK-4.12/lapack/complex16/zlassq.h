extern int v3p_netlib_zlassq_(
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *x,
  v3p_netlib_integer *incx,
  v3p_netlib_doublereal *scale,
  v3p_netlib_doublereal *sumsq
  );
