extern int v3p_netlib_zgetc2_(
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_integer *ipiv,
  v3p_netlib_integer *jpiv,
  v3p_netlib_integer *info
  );
