extern int v3p_netlib_zlaswp_(
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_integer *k1,
  v3p_netlib_integer *k2,
  v3p_netlib_integer *ipiv,
  v3p_netlib_integer *incx
  );
