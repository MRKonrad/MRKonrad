extern int v3p_netlib_ztrsen_(
  char *job,
  char *compq,
  v3p_netlib_logical *select,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *t,
  v3p_netlib_integer *ldt,
  v3p_netlib_doublecomplex *q,
  v3p_netlib_integer *ldq,
  v3p_netlib_doublecomplex *w,
  v3p_netlib_integer *m,
  v3p_netlib_doublereal *s,
  v3p_netlib_doublereal *sep,
  v3p_netlib_doublecomplex *work,
  v3p_netlib_integer *lwork,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen job_len,
  v3p_netlib_ftnlen compq_len
  );
