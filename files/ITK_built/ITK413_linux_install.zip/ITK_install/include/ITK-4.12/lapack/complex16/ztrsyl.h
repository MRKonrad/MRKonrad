extern int v3p_netlib_ztrsyl_(
  char *trana,
  char *tranb,
  v3p_netlib_integer *isgn,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublecomplex *b,
  v3p_netlib_integer *ldb,
  v3p_netlib_doublecomplex *c__,
  v3p_netlib_integer *ldc,
  v3p_netlib_doublereal *scale,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen trana_len,
  v3p_netlib_ftnlen tranb_len
  );
