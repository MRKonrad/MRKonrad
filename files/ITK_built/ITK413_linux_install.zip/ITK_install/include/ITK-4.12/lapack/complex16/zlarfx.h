extern int v3p_netlib_zlarfx_(
  char *side,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *v,
  v3p_netlib_doublecomplex *tau,
  v3p_netlib_doublecomplex *c__,
  v3p_netlib_integer *ldc,
  v3p_netlib_doublecomplex *work,
  v3p_netlib_ftnlen side_len
  );
