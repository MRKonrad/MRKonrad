extern v3p_netlib_doublereal v3p_netlib_zlange_(
  char *norm,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublereal *work,
  v3p_netlib_ftnlen norm_len
  );
