extern int v3p_netlib_ztrevc_(
  char *side,
  char *howmny,
  v3p_netlib_logical *select,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *t,
  v3p_netlib_integer *ldt,
  v3p_netlib_doublecomplex *vl,
  v3p_netlib_integer *ldvl,
  v3p_netlib_doublecomplex *vr,
  v3p_netlib_integer *ldvr,
  v3p_netlib_integer *mm,
  v3p_netlib_integer *m,
  v3p_netlib_doublecomplex *work,
  v3p_netlib_doublereal *rwork,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen side_len,
  v3p_netlib_ftnlen howmny_len
  );
