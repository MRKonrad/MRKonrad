extern int v3p_netlib_zlartg_(
  v3p_netlib_doublecomplex *f,
  v3p_netlib_doublecomplex *g,
  v3p_netlib_doublereal *cs,
  v3p_netlib_doublecomplex *sn,
  v3p_netlib_doublecomplex *r__
  );
