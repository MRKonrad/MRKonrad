extern int v3p_netlib_zunmqr_(
  char *side,
  char *trans,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_integer *k,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublecomplex *tau,
  v3p_netlib_doublecomplex *c__,
  v3p_netlib_integer *ldc,
  v3p_netlib_doublecomplex *work,
  v3p_netlib_integer *lwork,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen side_len,
  v3p_netlib_ftnlen trans_len
  );
