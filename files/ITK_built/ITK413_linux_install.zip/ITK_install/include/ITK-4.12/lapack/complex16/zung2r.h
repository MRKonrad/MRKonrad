extern int v3p_netlib_zung2r_(
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_integer *k,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublecomplex *tau,
  v3p_netlib_doublecomplex *work,
  v3p_netlib_integer *info
  );
