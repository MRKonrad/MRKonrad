extern int v3p_netlib_zgghrd_(
  char *compq,
  char *compz,
  v3p_netlib_integer *n,
  v3p_netlib_integer *ilo,
  v3p_netlib_integer *ihi,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublecomplex *b,
  v3p_netlib_integer *ldb,
  v3p_netlib_doublecomplex *q,
  v3p_netlib_integer *ldq,
  v3p_netlib_doublecomplex *z__,
  v3p_netlib_integer *ldz,
  v3p_netlib_integer *info,
  v3p_netlib_ftnlen compq_len,
  v3p_netlib_ftnlen compz_len
  );
