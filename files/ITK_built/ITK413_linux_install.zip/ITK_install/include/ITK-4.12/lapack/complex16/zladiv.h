extern v3p_netlib_Z_f v3p_netlib_zladiv_(
  v3p_netlib_doublecomplex * ret_val,
  v3p_netlib_doublecomplex *x,
  v3p_netlib_doublecomplex *y
  );
