extern int v3p_netlib_zgeqr2_(
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublecomplex *tau,
  v3p_netlib_doublecomplex *work,
  v3p_netlib_integer *info
  );
