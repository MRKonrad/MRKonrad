extern v3p_netlib_integer v3p_netlib_izmax1_(
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *cx,
  v3p_netlib_integer *incx
  );
