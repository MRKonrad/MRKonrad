extern v3p_netlib_integer v3p_netlib_ieeeck_(
  v3p_netlib_integer *ispec,
  v3p_netlib_real *zero,
  v3p_netlib_real *one
  );
