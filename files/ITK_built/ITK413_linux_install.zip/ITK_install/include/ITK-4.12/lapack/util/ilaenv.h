extern v3p_netlib_integer v3p_netlib_ilaenv_(
  v3p_netlib_integer *ispec,
  char *name__,
  char *opts,
  v3p_netlib_integer *n1,
  v3p_netlib_integer *n2,
  v3p_netlib_integer *n3,
  v3p_netlib_integer *n4,
  v3p_netlib_ftnlen name_len,
  v3p_netlib_ftnlen opts_len
  );
