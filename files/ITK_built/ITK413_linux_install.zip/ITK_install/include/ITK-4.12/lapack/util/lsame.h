extern v3p_netlib_logical v3p_netlib_lsame_(
  const char *ca,
  const char *cb,
  v3p_netlib_ftnlen ca_len,
  v3p_netlib_ftnlen cb_len
  );
