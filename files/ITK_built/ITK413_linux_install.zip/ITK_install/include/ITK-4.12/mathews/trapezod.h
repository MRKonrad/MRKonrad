extern int v3p_netlib_trapru_(
  v3p_netlib_doublereal (*f)(v3p_netlib_doublereal*),
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *b,
  v3p_netlib_integer *m,
  v3p_netlib_doublereal *trule
  );
extern int v3p_netlib_xtrapru_(
  v3p_netlib_doublereal (*f)(v3p_netlib_doublereal*),
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *b,
  v3p_netlib_integer *m,
  v3p_netlib_doublereal *trule
  );
