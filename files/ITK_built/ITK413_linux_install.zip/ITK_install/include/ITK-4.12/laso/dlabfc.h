extern int v3p_netlib_dlabfc_(
  v3p_netlib_integer *n,
  v3p_netlib_integer *nband,
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *sigma,
  v3p_netlib_integer *number,
  v3p_netlib_integer *lde,
  v3p_netlib_doublereal *eigvec,
  v3p_netlib_integer *numl,
  v3p_netlib_integer *ldad,
  v3p_netlib_doublereal *atemp,
  v3p_netlib_doublereal *d__,
  v3p_netlib_doublereal *atol
  );
