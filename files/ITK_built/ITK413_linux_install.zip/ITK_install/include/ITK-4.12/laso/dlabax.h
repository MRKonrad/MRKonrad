extern int v3p_netlib_dlabax_(
  v3p_netlib_integer *n,
  v3p_netlib_integer *nband,
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *x,
  v3p_netlib_doublereal *y
  );
