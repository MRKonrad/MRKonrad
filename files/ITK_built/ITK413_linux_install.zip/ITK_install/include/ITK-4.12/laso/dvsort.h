extern int v3p_netlib_dvsort_(
  v3p_netlib_integer *num,
  v3p_netlib_doublereal *val,
  v3p_netlib_doublereal *res,
  v3p_netlib_integer *iflag,
  v3p_netlib_doublereal *v,
  v3p_netlib_integer *nmvec,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *vec
  );
