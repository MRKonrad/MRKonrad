extern int v3p_netlib_dlabcm_(
  v3p_netlib_integer *n,
  v3p_netlib_integer *nband,
  v3p_netlib_integer *nl,
  v3p_netlib_integer *nr,
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *eigval,
  v3p_netlib_integer *lde,
  v3p_netlib_doublereal *eigvec,
  v3p_netlib_doublereal *atol,
  v3p_netlib_doublereal *artol,
  v3p_netlib_doublereal *bound,
  v3p_netlib_doublereal *atemp,
  v3p_netlib_doublereal *d__,
  v3p_netlib_doublereal *vtemp
  );
