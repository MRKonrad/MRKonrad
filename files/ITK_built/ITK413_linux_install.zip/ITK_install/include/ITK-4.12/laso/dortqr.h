extern int v3p_netlib_dortqr_(
  v3p_netlib_integer *nz,
  v3p_netlib_integer *n,
  v3p_netlib_integer *nblock,
  v3p_netlib_doublereal *z__,
  v3p_netlib_doublereal *b
  );
