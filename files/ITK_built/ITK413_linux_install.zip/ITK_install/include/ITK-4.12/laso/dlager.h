extern int v3p_netlib_dlager_(
  v3p_netlib_integer *n,
  v3p_netlib_integer *nband,
  v3p_netlib_integer *nstart,
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *tmin,
  v3p_netlib_doublereal *tmax
  );
