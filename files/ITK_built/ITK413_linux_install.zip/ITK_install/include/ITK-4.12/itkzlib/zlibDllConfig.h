#ifndef _zlibDllConfig_h
#define _zlibDllConfig_h

/* #undef ZLIB_DLL */

#endif
