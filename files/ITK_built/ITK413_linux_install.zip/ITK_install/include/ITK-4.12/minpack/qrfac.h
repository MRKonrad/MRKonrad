extern int v3p_netlib_qrfac_(
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_logical *pivot,
  v3p_netlib_integer *ipvt,
  v3p_netlib_integer *lipvt,
  v3p_netlib_doublereal *rdiag,
  v3p_netlib_doublereal *acnorm,
  v3p_netlib_doublereal *wa
  );
