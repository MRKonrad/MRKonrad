extern int v3p_netlib_lmpar_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *r__,
  v3p_netlib_integer *ldr,
  v3p_netlib_integer *ipvt,
  v3p_netlib_doublereal *diag,
  v3p_netlib_doublereal *qtb,
  v3p_netlib_doublereal *delta,
  v3p_netlib_doublereal *par,
  v3p_netlib_doublereal *x,
  v3p_netlib_doublereal *sdiag,
  v3p_netlib_doublereal *wa1,
  v3p_netlib_doublereal *wa2
  );
