extern v3p_netlib_doublereal v3p_netlib_dpmpar_(
  v3p_netlib_integer *i__
  );
