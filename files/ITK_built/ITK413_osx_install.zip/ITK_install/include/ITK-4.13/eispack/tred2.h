extern int v3p_netlib_tred2_(
  v3p_netlib_integer *nm,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *d__,
  v3p_netlib_doublereal *e,
  v3p_netlib_doublereal *z__
  );
