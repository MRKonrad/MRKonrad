extern int v3p_netlib_rebak_(
  v3p_netlib_integer *nm,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *b,
  v3p_netlib_doublereal *dl,
  v3p_netlib_integer *m,
  v3p_netlib_doublereal *z__
  );
