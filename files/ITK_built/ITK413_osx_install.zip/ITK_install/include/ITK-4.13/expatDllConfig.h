#ifndef _expatDllConfig_h
#define _expatDllConfig_h

/* #undef ITK_EXPAT_STATIC */
#include "itk_expat_mangle.h"

#endif
