extern v3p_netlib_doublereal v3p_netlib_snrm2_(
  v3p_netlib_integer *n,
  v3p_netlib_real *x,
  v3p_netlib_integer *incx
  );
