extern int v3p_netlib_dtrmm_(
  char *side,
  char *uplo,
  char *transa,
  char *diag,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *alpha,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda,
  v3p_netlib_doublereal *b,
  v3p_netlib_integer *ldb,
  v3p_netlib_ftnlen side_len,
  v3p_netlib_ftnlen uplo_len,
  v3p_netlib_ftnlen transa_len,
  v3p_netlib_ftnlen diag_len
  );
