extern int v3p_netlib_saxpy_(
  v3p_netlib_integer *n,
  v3p_netlib_real *sa,
  v3p_netlib_real *sx,
  v3p_netlib_integer *incx,
  v3p_netlib_real *sy,
  v3p_netlib_integer *incy
  );
