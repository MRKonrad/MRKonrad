extern int v3p_netlib_zgerc_(
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *alpha,
  v3p_netlib_doublecomplex *x,
  v3p_netlib_integer *incx,
  v3p_netlib_doublecomplex *y,
  v3p_netlib_integer *incy,
  v3p_netlib_doublecomplex *a,
  v3p_netlib_integer *lda
  );
